# Automatically generated code: EDIT AT YOUR OWN RISK
from traits import api as traits
from traitsui.item import Item, spring
from traitsui.group import HGroup
from traitsui.view import View

from tvtk import vtk_module as vtk
from tvtk import tvtk_base
from tvtk.tvtk_base_handler import TVTKBaseHandler
from tvtk import messenger
from tvtk.tvtk_base import deref_vtk
from tvtk import array_handler
from tvtk.array_handler import deref_array
from tvtk.tvtk_classes.tvtk_helper import wrap_vtk

nan = float('nan')


def InstanceEditor(*args, **kw):
    from traitsui.editors.api import InstanceEditor as Editor
    return Editor(view_name="handler.view")

try:
    long
except NameError:
    # Silly workaround for Python3.
    long = int

inf = float('inf')

from tvtk.tvtk_classes.object import Object


class DataObjectTypes(Object):
    """
    DataObjectTypes - no description provided.
    
    Superclass: Object
    
    """
    def __init__(self, obj=None, update=True, **traits):
        tvtk_base.TVTKBase.__init__(self, vtk.vtkDataObjectTypes, obj, update, **traits)
    
    def get_class_name_from_type_id(self, *args):
        """
        get_class_name_from_type_id(typeId:int) -> str
        C++: static const char *get_class_name_from_type_id(int typeId)
        Given an int (as defined in Type.h) identifier for a class
        return it's classname.
        """
        ret = self._wrap_call(self._vtk_obj.GetClassNameFromTypeId, *args)
        return ret

    def get_common_base_type_id(self, *args):
        """
        get_common_base_type_id(typeA:int, typeB:int) -> int
        C++: static int get_common_base_type_id(int typeA, int typeB)
        Given two data types, returns the closest common data type. If
        both data types ids are valid, at worse, this will return
        `VTK_DATA_OBJECT`. If one of the types is invalid (or unknown),
        simply returns the valid (or known) type. If both are invalid,
        returns -1.
        """
        ret = self._wrap_call(self._vtk_obj.GetCommonBaseTypeId, *args)
        return ret

    def get_type_id_from_class_name(self, *args):
        """
        get_type_id_from_class_name(classname:str) -> int
        C++: static int get_type_id_from_class_name(const char *classname)
        Given a data object classname, return it's int identified (as
        defined in Type.h)
        """
        ret = self._wrap_call(self._vtk_obj.GetTypeIdFromClassName, *args)
        return ret

    def new_data_object(self, *args):
        """
        new_data_object(classname:str) -> DataObject
        C++: static DataObject *new_data_object(const char *classname)
        new_data_object(typeId:int) -> DataObject
        C++: static DataObject *new_data_object(int typeId)
        Create (New) and return a data object of the given classname.
        """
        ret = self._wrap_call(self._vtk_obj.NewDataObject, *args)
        return wrap_vtk(ret)

    def type_id_is_a(self, *args):
        """
        type_id_is_a(typeId:int, targetTypeId:int) -> bool
        C++: static bool type_id_is_a(int typeId, int targetTypeId)"""
        ret = self._wrap_call(self._vtk_obj.TypeIdIsA, *args)
        return ret

    _updateable_traits_ = \
    (('debug', 'GetDebug'), ('global_warning_display',
    'GetGlobalWarningDisplay'), ('reference_count', 'GetReferenceCount'))
    
    _allow_update_failure_ = \
    ()
    
    _full_traitnames_list_ = \
    (['debug', 'global_warning_display'])
    
    def trait_view(self, name=None, view_element=None):
        if view_element is not None or name not in (None, '', 'traits_view', 'full_traits_view', 'view'):
            return super(DataObjectTypes, self).trait_view(name, view_element)
        if name == 'full_traits_view':
            full_traits_view = \
            View((Item("handler._full_traits_list",show_label=False)),
            title='Edit DataObjectTypes properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return full_traits_view
        elif name == 'view':
            view = \
            View(([], [], []),
            title='Edit DataObjectTypes properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return view
        elif name in (None, 'traits_view'):
            traits_view = \
            View((HGroup(spring, "handler.view_type", show_border=True), 
            Item("handler.info.object", editor = InstanceEditor(view_name="handler.view"), style = "custom", show_label=False)),
            title='Edit DataObjectTypes properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return traits_view
            

