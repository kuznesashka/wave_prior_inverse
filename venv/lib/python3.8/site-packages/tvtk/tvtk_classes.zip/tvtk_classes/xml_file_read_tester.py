# Automatically generated code: EDIT AT YOUR OWN RISK
from traits import api as traits
from traitsui.item import Item, spring
from traitsui.group import HGroup
from traitsui.view import View

from tvtk import vtk_module as vtk
from tvtk import tvtk_base
from tvtk.tvtk_base_handler import TVTKBaseHandler
from tvtk import messenger
from tvtk.tvtk_base import deref_vtk
from tvtk import array_handler
from tvtk.array_handler import deref_array
from tvtk.tvtk_classes.tvtk_helper import wrap_vtk

nan = float('nan')


def InstanceEditor(*args, **kw):
    from traitsui.editors.api import InstanceEditor as Editor
    return Editor(view_name="handler.view")

try:
    long
except NameError:
    # Silly workaround for Python3.
    long = int

inf = float('inf')

from tvtk.tvtk_classes.xml_parser import XMLParser


class XMLFileReadTester(XMLParser):
    """
    XMLFileReadTester - Utility class for XMLReader and subclasses.
    
    Superclass: XMLParser
    
    XMLFileReadTester reads the smallest part of a file necessary to
    determine whether it is a VTK XML file.  If so, it extracts the file
    type and version number.
    
    """
    def __init__(self, obj=None, update=True, **traits):
        tvtk_base.TVTKBase.__init__(self, vtk.vtkXMLFileReadTester, obj, update, **traits)
    
    def _get_file_data_type(self):
        return self._vtk_obj.GetFileDataType()
    file_data_type = traits.Property(_get_file_data_type, desc=\
        """
        Get the data type of the XML file tested.  If the file could not
        be read, returns nullptr.
        """
    )

    def _get_file_version(self):
        return self._vtk_obj.GetFileVersion()
    file_version = traits.Property(_get_file_version, desc=\
        """
        Get the file version of the XML file tested.  If the file could
        not be read, returns nullptr.
        """
    )

    def test_read_file(self):
        """
        test_read_file(self) -> int
        C++: int test_read_file()
        Try to read the file given by file_name.  Returns 1 if the file is
        a VTK XML file, and 0 otherwise.
        """
        ret = self._vtk_obj.TestReadFile()
        return ret
        

    _updateable_traits_ = \
    (('debug', 'GetDebug'), ('global_warning_display',
    'GetGlobalWarningDisplay'), ('encoding', 'GetEncoding'), ('file_name',
    'GetFileName'), ('ignore_character_data', 'GetIgnoreCharacterData'),
    ('reference_count', 'GetReferenceCount'))
    
    _allow_update_failure_ = \
    ()
    
    _full_traitnames_list_ = \
    (['debug', 'global_warning_display', 'encoding', 'file_name',
    'ignore_character_data'])
    
    def trait_view(self, name=None, view_element=None):
        if view_element is not None or name not in (None, '', 'traits_view', 'full_traits_view', 'view'):
            return super(XMLFileReadTester, self).trait_view(name, view_element)
        if name == 'full_traits_view':
            full_traits_view = \
            View((Item("handler._full_traits_list",show_label=False)),
            title='Edit XMLFileReadTester properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return full_traits_view
        elif name == 'view':
            view = \
            View(([], [], ['encoding', 'file_name', 'ignore_character_data']),
            title='Edit XMLFileReadTester properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return view
        elif name in (None, 'traits_view'):
            traits_view = \
            View((HGroup(spring, "handler.view_type", show_border=True), 
            Item("handler.info.object", editor = InstanceEditor(view_name="handler.view"), style = "custom", show_label=False)),
            title='Edit XMLFileReadTester properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return traits_view
            

