# Automatically generated code: EDIT AT YOUR OWN RISK
from traits import api as traits
from traitsui.item import Item, spring
from traitsui.group import HGroup
from traitsui.view import View

from tvtk import vtk_module as vtk
from tvtk import tvtk_base
from tvtk.tvtk_base_handler import TVTKBaseHandler
from tvtk import messenger
from tvtk.tvtk_base import deref_vtk
from tvtk import array_handler
from tvtk.array_handler import deref_array
from tvtk.tvtk_classes.tvtk_helper import wrap_vtk

nan = float('nan')


def InstanceEditor(*args, **kw):
    from traitsui.editors.api import InstanceEditor as Editor
    return Editor(view_name="handler.view")

try:
    long
except NameError:
    # Silly workaround for Python3.
    long = int

inf = float('inf')

from tvtk.tvtk_classes.web_gl_object import WebGLObject


class WebGLPolyData(WebGLObject):
    """
    WebGLPolyData - poly_data representation for web_gl.
    
    Superclass: WebGLObject
    
    """
    def __init__(self, obj=None, update=True, **traits):
        tvtk_base.TVTKBase.__init__(self, vtk.vtkWebGLPolyData, obj, update, **traits)
    
    def get_points(self, *args):
        """
        get_points(self, polydata:TriangleFilter, actor:Actor,
            maxSize:int) -> None
        C++: void get_points(TriangleFilter *polydata, Actor *actor,
            int maxSize)"""
        my_args = [deref_vtk(x) for x in args]
        ret = self._wrap_call(self._vtk_obj.GetPoints, *my_args)
        return ret

    def set_points(self, *args):
        """
        set_points(self, points:[float, ...], numberOfPoints:int,
            colors:[int, ...], maxSize:int) -> None
        C++: void set_points(float *points, int numberOfPoints,
            unsigned char *colors, int maxSize)"""
        ret = self._wrap_call(self._vtk_obj.SetPoints, *args)
        return ret

    def get_colors_from_point_data(self, *args):
        """
        get_colors_from_point_data(self, color:[int, ...],
            pointdata:PointData, polydata:PolyData, actor:Actor)
            -> None
        C++: void get_colors_from_point_data(unsigned char *color,
            PointData *pointdata, PolyData *polydata,
            Actor *actor)"""
        my_args = [deref_vtk(x) for x in args]
        ret = self._wrap_call(self._vtk_obj.GetColorsFromPointData, *my_args)
        return ret

    def get_colors_from_poly_data(self, *args):
        """
        get_colors_from_poly_data(self, color:[int, ...],
            polydata:PolyData, actor:Actor) -> None
        C++: void get_colors_from_poly_data(unsigned char *color,
            PolyData *polydata, Actor *actor)"""
        my_args = [deref_vtk(x) for x in args]
        ret = self._wrap_call(self._vtk_obj.GetColorsFromPolyData, *my_args)
        return ret

    def get_lines(self, *args):
        """
        get_lines(self, polydata:TriangleFilter, actor:Actor,
            lineMaxSize:int) -> None
        C++: void get_lines(TriangleFilter *polydata, Actor *actor,
            int lineMaxSize)"""
        my_args = [deref_vtk(x) for x in args]
        ret = self._wrap_call(self._vtk_obj.GetLines, *my_args)
        return ret

    def get_lines_from_polygon(self, *args):
        """
        get_lines_from_polygon(self, mapper:Mapper, actor:Actor,
            lineMaxSize:int, edgeColor:[float, ...]) -> None
        C++: void get_lines_from_polygon(Mapper *mapper, Actor *actor,
            int lineMaxSize, double *edgeColor)"""
        my_args = [deref_vtk(x) for x in args]
        ret = self._wrap_call(self._vtk_obj.GetLinesFromPolygon, *my_args)
        return ret

    def get_polygons_from_cell_data(self, *args):
        """
        get_polygons_from_cell_data(self, polydata:TriangleFilter,
            actor:Actor, maxSize:int) -> None
        C++: void get_polygons_from_cell_data(TriangleFilter *polydata,
            Actor *actor, int maxSize)"""
        my_args = [deref_vtk(x) for x in args]
        ret = self._wrap_call(self._vtk_obj.GetPolygonsFromCellData, *my_args)
        return ret

    def get_polygons_from_point_data(self, *args):
        """
        get_polygons_from_point_data(self, polydata:TriangleFilter,
            actor:Actor, maxSize:int) -> None
        C++: void get_polygons_from_point_data(TriangleFilter *polydata,
            Actor *actor, int maxSize)"""
        my_args = [deref_vtk(x) for x in args]
        ret = self._wrap_call(self._vtk_obj.GetPolygonsFromPointData, *my_args)
        return ret

    def set_line(self, *args):
        """
        set_line(self, _points:[float, ...], _numberOfPoints:int,
            _index:[int, ...], _numberOfIndex:int, _colors:[int, ...],
            maxSize:int) -> None
        C++: void set_line(float *_points, int _numberOfPoints,
            int *_index, int _numberOfIndex, unsigned char *_colors,
            int maxSize)"""
        ret = self._wrap_call(self._vtk_obj.SetLine, *args)
        return ret

    def set_mesh(self, *args):
        """
        set_mesh(self, _vertices:[float, ...], _numberOfVertices:int,
            _index:[int, ...], _numberOfIndexes:int, _normals:[float,
            ...], _colors:[int, ...], _tcoords:[float, ...], maxSize:int)
            -> None
        C++: void set_mesh(float *_vertices, int _numberOfVertices,
            int *_index, int _numberOfIndexes, float *_normals,
            unsigned char *_colors, float *_tcoords, int maxSize)"""
        ret = self._wrap_call(self._vtk_obj.SetMesh, *args)
        return ret

    _updateable_traits_ = \
    (('debug', 'GetDebug'), ('global_warning_display',
    'GetGlobalWarningDisplay'), ('id', 'GetId'), ('layer', 'GetLayer'),
    ('renderer_id', 'GetRendererId'), ('reference_count',
    'GetReferenceCount'))
    
    _allow_update_failure_ = \
    ()
    
    _full_traitnames_list_ = \
    (['debug', 'global_warning_display', 'id', 'layer', 'renderer_id'])
    
    def trait_view(self, name=None, view_element=None):
        if view_element is not None or name not in (None, '', 'traits_view', 'full_traits_view', 'view'):
            return super(WebGLPolyData, self).trait_view(name, view_element)
        if name == 'full_traits_view':
            full_traits_view = \
            View((Item("handler._full_traits_list",show_label=False)),
            title='Edit WebGLPolyData properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return full_traits_view
        elif name == 'view':
            view = \
            View(([], [], ['id', 'layer', 'renderer_id']),
            title='Edit WebGLPolyData properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return view
        elif name in (None, 'traits_view'):
            traits_view = \
            View((HGroup(spring, "handler.view_type", show_border=True), 
            Item("handler.info.object", editor = InstanceEditor(view_name="handler.view"), style = "custom", show_label=False)),
            title='Edit WebGLPolyData properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return traits_view
            

