# Automatically generated code: EDIT AT YOUR OWN RISK
from traits import api as traits
from traitsui.item import Item, spring
from traitsui.group import HGroup
from traitsui.view import View

from tvtk import vtk_module as vtk
from tvtk import tvtk_base
from tvtk.tvtk_base_handler import TVTKBaseHandler
from tvtk import messenger
from tvtk.tvtk_base import deref_vtk
from tvtk import array_handler
from tvtk.array_handler import deref_array
from tvtk.tvtk_classes.tvtk_helper import wrap_vtk

nan = float('nan')


def InstanceEditor(*args, **kw):
    from traitsui.editors.api import InstanceEditor as Editor
    return Editor(view_name="handler.view")

try:
    long
except NameError:
    # Silly workaround for Python3.
    long = int

inf = float('inf')

from tvtk.tvtk_classes.object import Object


class OpenGLCellToVTKCellMap(Object):
    """
    OpenGLCellToVTKCellMap - open_gl rendering utility functions
    
    Superclass: Object
    
    OpenGLCellToVTKCellMap provides functions map from opengl
    primitive ID to vtk
    
    """
    def __init__(self, obj=None, update=True, **traits):
        tvtk_base.TVTKBase.__init__(self, vtk.vtkOpenGLCellToVTKCellMap, obj, update, **traits)
    
    def _get_final_offset(self):
        return self._vtk_obj.GetFinalOffset()
    final_offset = traits.Property(_get_final_offset, desc=\
        """
        
        """
    )

    def _get_primitive_offsets(self):
        return self._vtk_obj.GetPrimitiveOffsets()
    primitive_offsets = traits.Property(_get_primitive_offsets, desc=\
        """
        
        """
    )

    def _get_size(self):
        return self._vtk_obj.GetSize()
    size = traits.Property(_get_size, desc=\
        """
        
        """
    )

    def get_value(self, *args):
        """
        get_value(self, i:int) -> int
        C++: IdType get_value(size_t i)"""
        ret = self._wrap_call(self._vtk_obj.GetValue, *args)
        return ret

    def convert_open_gl_cell_id_to_vtk_cell_id(self, *args):
        """
        convert_open_gl_cell_id_to_vtk_cell_id(self, pointPicking:bool,
            openGLId:int) -> int
        C++: IdType convert_open_gl_cell_id_to_vtk_cell_id(bool pointPicking,
            IdType openGLId)"""
        ret = self._wrap_call(self._vtk_obj.ConvertOpenGLCellIdToVTKCellId, *args)
        return ret

    def set_start_offset(self, *args):
        """
        set_start_offset(self, start:int) -> None
        C++: void set_start_offset(IdType start)"""
        ret = self._wrap_call(self._vtk_obj.SetStartOffset, *args)
        return ret

    _updateable_traits_ = \
    (('debug', 'GetDebug'), ('global_warning_display',
    'GetGlobalWarningDisplay'), ('reference_count', 'GetReferenceCount'))
    
    _allow_update_failure_ = \
    ()
    
    _full_traitnames_list_ = \
    (['debug', 'global_warning_display'])
    
    def trait_view(self, name=None, view_element=None):
        if view_element is not None or name not in (None, '', 'traits_view', 'full_traits_view', 'view'):
            return super(OpenGLCellToVTKCellMap, self).trait_view(name, view_element)
        if name == 'full_traits_view':
            full_traits_view = \
            View((Item("handler._full_traits_list",show_label=False)),
            title='Edit OpenGLCellToVTKCellMap properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return full_traits_view
        elif name == 'view':
            view = \
            View(([], [], []),
            title='Edit OpenGLCellToVTKCellMap properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return view
        elif name in (None, 'traits_view'):
            traits_view = \
            View((HGroup(spring, "handler.view_type", show_border=True), 
            Item("handler.info.object", editor = InstanceEditor(view_name="handler.view"), style = "custom", show_label=False)),
            title='Edit OpenGLCellToVTKCellMap properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return traits_view
            

