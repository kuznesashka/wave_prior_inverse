# Automatically generated code: EDIT AT YOUR OWN RISK
from traits import api as traits
from traitsui.item import Item, spring
from traitsui.group import HGroup
from traitsui.view import View

from tvtk import vtk_module as vtk
from tvtk import tvtk_base
from tvtk.tvtk_base_handler import TVTKBaseHandler
from tvtk import messenger
from tvtk.tvtk_base import deref_vtk
from tvtk import array_handler
from tvtk.array_handler import deref_array
from tvtk.tvtk_classes.tvtk_helper import wrap_vtk

nan = float('nan')


def InstanceEditor(*args, **kw):
    from traitsui.editors.api import InstanceEditor as Editor
    return Editor(view_name="handler.view")

try:
    long
except NameError:
    # Silly workaround for Python3.
    long = int

inf = float('inf')

from tvtk.tvtk_classes.lagrangian_basic_integration_model import LagrangianBasicIntegrationModel


class LagrangianMatidaIntegrationModel(LagrangianBasicIntegrationModel):
    """
    LagrangianMatidaIntegrationModel -
    LagrangianBasicIntegrationModel implementation
    
    Superclass: LagrangianBasicIntegrationModel
    
    LagrangianBasicIntegrationModel implementation using article : "Matida, E. A., et al.
    "Improved numerical simulation of aerosol deposition in an idealized
    mouth-throat." Journal of Aerosol Science 35.1 (2004): 1-19." Input
    Array to process are expected as follow : Index 1 is the
    "flow_velocity" from flow input in the tracker Index 2 is the
    "flow_density" from flow input in the tracker Index 3 is the
    "flow_dynamic_viscosity" from flow input in the tracker Index 4 is the
    "particle_diameter" from seed (source) input in the tracker Index 5 is
    the "particle_density" from seed (source) input in the tracker
    
    @sa
    LagrangianParticleTracker LagrangianParticle
    LagrangianBasicIntegrationModel
    
    """
    def __init__(self, obj=None, update=True, **traits):
        tvtk_base.TVTKBase.__init__(self, vtk.vtkLagrangianMatidaIntegrationModel, obj, update, **traits)
    
    _updateable_traits_ = \
    (('non_planar_quad_support', 'GetNonPlanarQuadSupport'),
    ('use_initial_integration_time', 'GetUseInitialIntegrationTime'),
    ('debug', 'GetDebug'), ('global_warning_display',
    'GetGlobalWarningDisplay'), ('locators_built', 'GetLocatorsBuilt'),
    ('number_of_tracked_user_data', 'GetNumberOfTrackedUserData'),
    ('reference_count', 'GetReferenceCount'))
    
    _allow_update_failure_ = \
    ()
    
    _full_traitnames_list_ = \
    (['debug', 'global_warning_display', 'non_planar_quad_support',
    'use_initial_integration_time', 'locators_built',
    'number_of_tracked_user_data'])
    
    def trait_view(self, name=None, view_element=None):
        if view_element is not None or name not in (None, '', 'traits_view', 'full_traits_view', 'view'):
            return super(LagrangianMatidaIntegrationModel, self).trait_view(name, view_element)
        if name == 'full_traits_view':
            full_traits_view = \
            View((Item("handler._full_traits_list",show_label=False)),
            title='Edit LagrangianMatidaIntegrationModel properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return full_traits_view
        elif name == 'view':
            view = \
            View((['non_planar_quad_support', 'use_initial_integration_time'], [],
            ['locators_built', 'number_of_tracked_user_data']),
            title='Edit LagrangianMatidaIntegrationModel properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return view
        elif name in (None, 'traits_view'):
            traits_view = \
            View((HGroup(spring, "handler.view_type", show_border=True), 
            Item("handler.info.object", editor = InstanceEditor(view_name="handler.view"), style = "custom", show_label=False)),
            title='Edit LagrangianMatidaIntegrationModel properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return traits_view
            

